from django.apps import AppConfig


class AppOneConfig(AppConfig):
    name = 'app_one'
